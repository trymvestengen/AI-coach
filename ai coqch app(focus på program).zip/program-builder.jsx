// program-builder.jsx — manual routine creation flow
//
// Hevy-style hub + builder, in our visual language (deep orange accent,
// warm dark, Geist + Geist Mono, sharp 0.5px borders).
//
// Screens:
//   1. ScreenWorkoutHub      — entry: active program card + Start Empty + Routines grid
//   2. ScreenCreateRoutine   — empty + populated routine builder (title + exercise list)
//   3. ScreenExercisePicker  — modal: search, equipment + muscle filter, popular list
//   4. ScreenActiveWorkout   — live "Log workout" with timer, volume, sets

// ────────────────────────────────────────────────────────────────────
// Sample data — popular exercises for the picker. Each has a placeholder
// thumb (no real assets) drawn with SVG to honor "placeholder over bad attempt".
// ────────────────────────────────────────────────────────────────────
const AC_EXERCISE_LIBRARY = [
  { id: 'bench-bb',   name: 'Bench Press',          equip: 'Barbell',  muscle: 'Chest' },
  { id: 'bench-db',   name: 'Bench Press',          equip: 'Dumbbell', muscle: 'Chest' },
  { id: 'row-bb',     name: 'Bent-over Row',        equip: 'Barbell',  muscle: 'Upper Back' },
  { id: 'curl-db',    name: 'Bicep Curl',           equip: 'Dumbbell', muscle: 'Biceps' },
  { id: 'fly-cable',  name: 'Cable Fly Crossover',  equip: 'Cable',    muscle: 'Chest' },
  { id: 'dl',         name: 'Deadlift',             equip: 'Barbell',  muscle: 'Glutes' },
  { id: 'face-pull',  name: 'Face Pull',            equip: 'Cable',    muscle: 'Shoulders' },
  { id: 'incline-db', name: 'Incline Press',        equip: 'Dumbbell', muscle: 'Chest' },
  { id: 'lat-pull',   name: 'Lat Pulldown',         equip: 'Cable',    muscle: 'Lats' },
  { id: 'leg-press',  name: 'Leg Press',            equip: 'Machine',  muscle: 'Quads' },
  { id: 'ohp-bb',     name: 'Overhead Press',       equip: 'Barbell',  muscle: 'Shoulders' },
  { id: 'pull-up',    name: 'Pull-up',              equip: 'Bodyweight', muscle: 'Lats' },
  { id: 'rdl',        name: 'Romanian Deadlift',    equip: 'Barbell',  muscle: 'Hamstrings' },
  { id: 'squat-bb',   name: 'Back Squat',           equip: 'Barbell',  muscle: 'Quads' },
  { id: 'tri-pd',     name: 'Triceps Pushdown',     equip: 'Cable',    muscle: 'Triceps' },
];

const AC_SAVED_ROUTINES = [
  { id: 'r1', name: 'Upper A — Push focus',   exercises: 6, lastUsed: '2d ago' },
  { id: 'r2', name: 'Upper B — Pull focus',   exercises: 6, lastUsed: '5d ago' },
  { id: 'r3', name: 'Lower A — Squat',        exercises: 5, lastUsed: '4d ago' },
  { id: 'r4', name: 'Lower B — Hinge',        exercises: 5, lastUsed: '7d ago' },
];

// ════════════════════════════════════════════════════════════════════
// 1. WORKOUT HUB
// ════════════════════════════════════════════════════════════════════
function ScreenWorkoutHub({ theme, accent, onStartEmpty, onNewRoutine, onOpenRoutine }) {
  return (
    <div style={{ background: theme.bg, minHeight: '100%', paddingBottom: 110 }}>
      <div style={{ height: 54 }}/>

      {/* Header */}
      <div style={{ padding: '12px 20px 18px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 11, color: theme.textTer, letterSpacing: 1.4, textTransform: 'uppercase', marginBottom: 6 }}>Workout</div>
          <div style={{ fontSize: 28, fontWeight: 620, color: theme.text, letterSpacing: -0.8, lineHeight: 1 }}>Build & train</div>
        </div>
        <div style={{
          fontFamily: 'var(--ac-mono)', fontSize: 10, color: accent,
          padding: '6px 9px', borderRadius: 999, background: `${accent}18`, border: `0.5px solid ${accent}40`,
          letterSpacing: 0.8, textTransform: 'uppercase', fontWeight: 600,
        }}>PRO</div>
      </div>

      {/* Quick start — empty workout */}
      <div style={{ padding: '0 20px 16px' }}>
        <button onClick={onStartEmpty} style={{
          all: 'unset', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12,
          width: '100%', boxSizing: 'border-box',
          padding: '18px 18px', borderRadius: AC_RADIUS.lg,
          background: theme.text, color: theme.bg,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: `${theme.bg}14`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}>
            <svg width="16" height="16" viewBox="0 0 16 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none"><path d="M8 2v12M2 8h12"/></svg>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: -0.2 }}>Start empty workout</div>
            <div style={{ fontSize: 12, opacity: 0.6, marginTop: 2 }}>Just lift. Add exercises as you go.</div>
          </div>
          <svg width="8" height="14" viewBox="0 0 8 14" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinecap="round"><path d="M2 1l4 6-4 6"/></svg>
        </button>
      </div>

      {/* Active program — concise card linking back to ScreenProgram */}
      <SectionHeader title="Active program" theme={theme}/>
      <div style={{ padding: '0 20px 22px' }}>
        <div style={{
          padding: '14px 16px', borderRadius: AC_RADIUS.lg,
          background: theme.surface1, border: `0.5px solid ${theme.border}`,
        }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: theme.text, letterSpacing: -0.2 }}>Hypertrophy 4×</div>
              <div style={{ fontSize: 11, color: theme.textSec, marginTop: 2, fontFamily: 'var(--ac-mono)', letterSpacing: 0.2 }}>Week 4 of 12 · Coach-built</div>
            </div>
            <div style={{ fontSize: 11, color: accent, fontFamily: 'var(--ac-mono)', letterSpacing: 0.4 }}>NEXT · Thu</div>
          </div>
          <div style={{ display: 'flex', gap: 3 }}>
            {Array.from({ length: 12 }).map((_, i) => {
              const done = i < 3, current = i === 3;
              return (
                <div key={i} style={{
                  flex: 1, height: 4, borderRadius: 2,
                  background: done ? accent : current ? `${accent}55` : theme.surface3,
                }}/>
              );
            })}
          </div>
        </div>
      </div>

      {/* Routines */}
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', padding: '0 20px', marginBottom: 12 }}>
        <div style={{ fontSize: 10, fontWeight: 600, color: theme.textTer, letterSpacing: 1.6, textTransform: 'uppercase' }}>My routines</div>
        <div style={{ fontSize: 12, color: theme.textSec, fontFamily: 'var(--ac-mono)', letterSpacing: 0.2 }}>{AC_SAVED_ROUTINES.length}</div>
      </div>

      <div style={{ padding: '0 20px 14px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {/* New routine tile */}
        <button onClick={onNewRoutine} style={{
          all: 'unset', cursor: 'pointer', boxSizing: 'border-box',
          padding: '18px 16px', borderRadius: AC_RADIUS.lg,
          background: `${accent}10`, border: `0.5px dashed ${accent}66`,
          display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
          minHeight: 110,
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: 10, background: accent,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="14" height="14" viewBox="0 0 14 14" stroke="#1a0f0a" strokeWidth="2" strokeLinecap="round" fill="none"><path d="M7 2v10M2 7h10"/></svg>
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: theme.text, letterSpacing: -0.2 }}>New routine</div>
            <div style={{ fontSize: 11, color: theme.textSec, marginTop: 2 }}>Build manually</div>
          </div>
        </button>

        {/* Browse library tile */}
        <div style={{
          padding: '18px 16px', borderRadius: AC_RADIUS.lg,
          background: theme.surface1, border: `0.5px solid ${theme.border}`,
          display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
          minHeight: 110,
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: 10,
            background: theme.surface3, border: `0.5px solid ${theme.border}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="14" height="14" viewBox="0 0 16 16" stroke={theme.text} strokeWidth="1.6" fill="none" strokeLinecap="round"><circle cx="7" cy="7" r="5"/><path d="M14 14l-3-3"/></svg>
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: theme.text, letterSpacing: -0.2 }}>Browse library</div>
            <div style={{ fontSize: 11, color: theme.textSec, marginTop: 2 }}>Coach-curated routines</div>
          </div>
        </div>
      </div>

      {/* Saved routine list */}
      <div style={{ padding: '0 20px' }}>
        <div style={{ background: theme.surface1, border: `0.5px solid ${theme.border}`, borderRadius: AC_RADIUS.lg, overflow: 'hidden' }}>
          {AC_SAVED_ROUTINES.map((r, i, a) => (
            <div key={r.id} role="button" tabIndex={0}
              onClick={() => onOpenRoutine && onOpenRoutine(r.id)}
              onKeyDown={(e) => { if ((e.key === 'Enter' || e.key === ' ') && onOpenRoutine) onOpenRoutine(r.id); }}
              style={{
              cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12,
              width: '100%', boxSizing: 'border-box',
              padding: '13px 16px',
              borderBottom: i < a.length-1 ? `0.5px solid ${theme.border}` : 'none',
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 9,
                background: theme.surface2, border: `0.5px solid ${theme.border}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                fontFamily: 'var(--ac-mono)', fontSize: 12, color: theme.textSec, fontWeight: 540, letterSpacing: 0.2,
              }}>{r.name.split(' ')[0].slice(0,2)}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 540, color: theme.text, letterSpacing: -0.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.name}</div>
                <div style={{ fontSize: 11, color: theme.textSec, marginTop: 2, fontFamily: 'var(--ac-mono)', letterSpacing: 0.2 }}>
                  {r.exercises} exercises · {r.lastUsed}
                </div>
              </div>
              <button onClick={(e) => e.stopPropagation()} style={{
                all: 'unset', cursor: 'pointer', padding: '6px 10px', borderRadius: 999,
                fontSize: 11, color: accent, fontWeight: 600, letterSpacing: 0.2,
                background: `${accent}14`, border: `0.5px solid ${accent}40`,
              }}>Start</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════
// 2. CREATE ROUTINE — title + exercise list builder
// ════════════════════════════════════════════════════════════════════
function ScreenCreateRoutine({ theme, accent, initialExercises = [], onCancel, onSave, onAddExercise }) {
  const [title, setTitle] = React.useState('');
  const [exercises, setExercises] = React.useState(initialExercises);
  const empty = exercises.length === 0;

  const updateEx = (id, patch) => setExercises(xs => xs.map(e => e.id === id ? { ...e, ...patch } : e));
  const removeEx = (id) => setExercises(xs => xs.filter(e => e.id !== id));
  const addSet = (id) => updateEx(id, { sets: (exercises.find(e => e.id === id).sets) + 1 });

  return (
    <div style={{ background: theme.bg, minHeight: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ height: 54 }}/>
      {/* Top bar */}
      <div style={{
        padding: '8px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        borderBottom: `0.5px solid ${theme.border}`,
      }}>
        <button onClick={onCancel} style={{
          all: 'unset', cursor: 'pointer', padding: '8px 12px',
          fontSize: 14, color: theme.textSec, fontWeight: 540,
        }}>Cancel</button>
        <div style={{ fontSize: 14, fontWeight: 600, color: theme.text, letterSpacing: -0.2 }}>New routine</div>
        <button onClick={onSave} disabled={empty || !title} style={{
          all: 'unset', cursor: empty || !title ? 'default' : 'pointer', padding: '8px 14px',
          fontSize: 14, color: empty || !title ? theme.textTer : accent, fontWeight: 600, letterSpacing: -0.1,
          opacity: empty || !title ? 0.5 : 1,
        }}>Save</button>
      </div>

      {/* Coach hint banner */}
      <div style={{
        margin: '12px 16px 0',
        padding: '10px 14px', borderRadius: AC_RADIUS.md,
        background: `${accent}10`, border: `0.5px solid ${accent}30`,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          width: 22, height: 22, borderRadius: 11, flexShrink: 0,
          background: `radial-gradient(closest-side, ${accent}, ${accent}22)`,
        }}/>
        <div style={{ fontSize: 12, color: theme.text, lineHeight: 1.4, flex: 1, textWrap: 'pretty' }}>
          Building manually. Want me to suggest sets and weights once you're done?
        </div>
        <button style={{
          all: 'unset', cursor: 'pointer', padding: '4px 6px', fontSize: 16, color: theme.textTer, lineHeight: 1,
        }}>×</button>
      </div>

      {/* Title field */}
      <div style={{ padding: '20px 20px 8px' }}>
        <input
          type="text" value={title} onChange={(e) => setTitle(e.target.value)}
          placeholder="Routine title"
          style={{
            width: '100%', boxSizing: 'border-box',
            background: 'transparent', border: 'none', outline: 'none',
            color: theme.text, fontFamily: 'inherit', fontSize: 26, fontWeight: 620, letterSpacing: -0.6,
            padding: 0,
          }}
        />
        <div style={{ height: 0.5, background: theme.border, marginTop: 8 }}/>
      </div>

      {/* Body */}
      {empty ? (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '20px 28px 40px' }}>
          <div style={{ marginBottom: 18, opacity: 0.55 }}>
            <DumbbellIcon color={theme.textTer} size={48}/>
          </div>
          <div style={{ fontSize: 15, color: theme.textSec, textAlign: 'center', lineHeight: 1.5, maxWidth: 240, marginBottom: 22 }}>
            Add an exercise to get started.
          </div>
          <PrimaryButton accent={accent} theme={theme} onClick={onAddExercise} fullWidth icon={
            <svg width="14" height="14" viewBox="0 0 14 14" stroke="#1a0f0a" strokeWidth="2" strokeLinecap="round" fill="none"><path d="M7 2v10M2 7h10"/></svg>
          }>Add exercise</PrimaryButton>
        </div>
      ) : (
        <div style={{ flex: 1, padding: '8px 20px 30px', overflow: 'auto' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {exercises.map((ex) => (
              <RoutineExerciseCard key={ex.id} ex={ex} theme={theme} accent={accent}
                onAddSet={() => addSet(ex.id)}
                onRemove={() => removeEx(ex.id)}
                onUpdate={(patch) => updateEx(ex.id, patch)}
              />
            ))}
          </div>
          <button onClick={onAddExercise} style={{
            all: 'unset', cursor: 'pointer', width: '100%', boxSizing: 'border-box',
            marginTop: 14, padding: '14px',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            borderRadius: AC_RADIUS.lg,
            background: 'transparent', border: `0.5px dashed ${theme.borderStrong}`,
            color: accent, fontSize: 14, fontWeight: 600,
          }}>
            <svg width="14" height="14" viewBox="0 0 14 14" stroke={accent} strokeWidth="2" strokeLinecap="round" fill="none"><path d="M7 2v10M2 7h10"/></svg>
            Add exercise
          </button>
        </div>
      )}
    </div>
  );
}

// ── Single exercise card in the builder (sets table) ───────────────
function RoutineExerciseCard({ ex, theme, accent, onAddSet, onRemove, onUpdate }) {
  const [open, setOpen] = React.useState(true);
  return (
    <div style={{
      background: theme.surface1, border: `0.5px solid ${theme.border}`,
      borderRadius: AC_RADIUS.lg, overflow: 'hidden',
    }}>
      {/* Card header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px' }}>
        <ExerciseThumb name={ex.name} theme={theme} size={36}/>
        <button onClick={() => setOpen(o => !o)} style={{
          all: 'unset', cursor: 'pointer', flex: 1, minWidth: 0,
        }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: theme.text, letterSpacing: -0.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{ex.name}</div>
          <div style={{ fontSize: 11, color: theme.textSec, marginTop: 2 }}>{ex.muscle} · {ex.equip}</div>
        </button>
        <button onClick={onRemove} style={{
          all: 'unset', cursor: 'pointer', width: 28, height: 28, borderRadius: 14,
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: theme.textTer,
        }}>
          <svg width="14" height="14" viewBox="0 0 14 14" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none">
            <circle cx="2" cy="7" r="0.8" fill="currentColor"/><circle cx="7" cy="7" r="0.8" fill="currentColor"/><circle cx="12" cy="7" r="0.8" fill="currentColor"/>
          </svg>
        </button>
      </div>

      {open && (
        <div style={{ borderTop: `0.5px solid ${theme.border}`, padding: '10px 14px 12px' }}>
          {/* Header row */}
          <div style={{
            display: 'grid', gridTemplateColumns: '32px 1fr 1fr', gap: 10,
            padding: '0 0 6px', fontSize: 10, color: theme.textTer,
            letterSpacing: 1.4, textTransform: 'uppercase', fontWeight: 600,
          }}>
            <div>Set</div><div>Reps</div><div>Weight (kg)</div>
          </div>
          {Array.from({ length: ex.sets }).map((_, i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '32px 1fr 1fr', gap: 10, alignItems: 'center',
              padding: '6px 0',
            }}>
              <div style={{
                fontFamily: 'var(--ac-mono)', fontSize: 13, color: theme.textSec,
                fontVariantNumeric: 'tabular-nums', textAlign: 'center',
              }}>{i+1}</div>
              <PlanField theme={theme} accent={accent} placeholder={ex.targetReps || '8-10'}/>
              <PlanField theme={theme} accent={accent} placeholder={String(ex.targetWeight ?? '—')}/>
            </div>
          ))}
          <button onClick={onAddSet} style={{
            all: 'unset', cursor: 'pointer', width: '100%', boxSizing: 'border-box',
            marginTop: 6, padding: '8px',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            borderRadius: 9,
            color: accent, fontSize: 12, fontWeight: 600,
            background: `${accent}10`,
          }}>
            <svg width="11" height="11" viewBox="0 0 12 12" stroke={accent} strokeWidth="1.8" strokeLinecap="round"><path d="M6 2v8M2 6h8"/></svg>
            Add set
          </button>
        </div>
      )}
    </div>
  );
}

function PlanField({ theme, accent, placeholder }) {
  const [v, setV] = React.useState('');
  const [focus, setFocus] = React.useState(false);
  return (
    <input
      value={v} onChange={(e) => setV(e.target.value)}
      onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
      placeholder={placeholder}
      style={{
        width: '100%', boxSizing: 'border-box', height: 32,
        padding: '0 10px', borderRadius: 8,
        background: theme.surface2, border: `0.5px solid ${focus ? accent : theme.border}`,
        color: theme.text, fontFamily: 'var(--ac-mono)', fontSize: 13, fontVariantNumeric: 'tabular-nums',
        outline: 'none', transition: 'border-color .15s',
      }}
    />
  );
}

// ════════════════════════════════════════════════════════════════════
// 3. EXERCISE PICKER — search + filters + popular list
// ════════════════════════════════════════════════════════════════════
function ScreenExercisePicker({ theme, accent, onCancel, onPick }) {
  const [q, setQ] = React.useState('');
  const [equip, setEquip] = React.useState('All');
  const [muscle, setMuscle] = React.useState('All');
  const [picked, setPicked] = React.useState([]);

  const filtered = AC_EXERCISE_LIBRARY.filter(e => {
    if (q && !e.name.toLowerCase().includes(q.toLowerCase())) return false;
    if (equip !== 'All' && e.equip !== equip) return false;
    if (muscle !== 'All' && e.muscle !== muscle) return false;
    return true;
  });

  const togglePick = (id) => setPicked(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  return (
    <div style={{ background: theme.bg, minHeight: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ height: 54 }}/>
      {/* Top bar */}
      <div style={{
        padding: '8px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        borderBottom: `0.5px solid ${theme.border}`,
      }}>
        <button onClick={onCancel} style={{
          all: 'unset', cursor: 'pointer', padding: '8px 12px', fontSize: 14, color: theme.textSec, fontWeight: 540,
        }}>Cancel</button>
        <div style={{ fontSize: 14, fontWeight: 600, color: theme.text, letterSpacing: -0.2 }}>Add exercise</div>
        <button onClick={() => onPick && onPick(picked)} disabled={picked.length === 0} style={{
          all: 'unset', cursor: picked.length ? 'pointer' : 'default', padding: '8px 14px',
          fontSize: 14, color: picked.length ? accent : theme.textTer, fontWeight: 600,
          opacity: picked.length ? 1 : 0.5,
        }}>Add{picked.length > 0 ? ` (${picked.length})` : ''}</button>
      </div>

      {/* Search */}
      <div style={{ padding: '14px 16px 10px' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, height: 42,
          padding: '0 14px', borderRadius: 12,
          background: theme.surface1, border: `0.5px solid ${theme.border}`,
        }}>
          <svg width="14" height="14" viewBox="0 0 16 16" stroke={theme.textTer} strokeWidth="1.6" fill="none" strokeLinecap="round"><circle cx="7" cy="7" r="5"/><path d="M14 14l-3-3"/></svg>
          <input
            value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search exercise"
            style={{
              flex: 1, background: 'transparent', border: 'none', outline: 'none',
              color: theme.text, fontFamily: 'inherit', fontSize: 14, padding: 0,
            }}
          />
        </div>

        {/* Filter chips */}
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <FilterChip theme={theme} accent={accent} active={equip !== 'All'}
            label={equip === 'All' ? 'All equipment' : equip}
            onClick={() => {
              const opts = ['All', 'Barbell', 'Dumbbell', 'Cable', 'Machine', 'Bodyweight'];
              const next = opts[(opts.indexOf(equip) + 1) % opts.length];
              setEquip(next);
            }}
          />
          <FilterChip theme={theme} accent={accent} active={muscle !== 'All'}
            label={muscle === 'All' ? 'All muscles' : muscle}
            onClick={() => {
              const opts = ['All', 'Chest', 'Upper Back', 'Lats', 'Shoulders', 'Biceps', 'Triceps', 'Quads', 'Glutes', 'Hamstrings'];
              const next = opts[(opts.indexOf(muscle) + 1) % opts.length];
              setMuscle(next);
            }}
          />
        </div>
      </div>

      <div style={{ padding: '0 20px 6px', fontSize: 11, color: theme.textTer, letterSpacing: 1.4, textTransform: 'uppercase', fontWeight: 600 }}>
        {q || equip !== 'All' || muscle !== 'All' ? `${filtered.length} matching` : 'Popular exercises'}
      </div>

      {/* List */}
      <div style={{ flex: 1, overflow: 'auto', padding: '8px 20px 30px' }}>
        <div style={{ background: theme.surface1, border: `0.5px solid ${theme.border}`, borderRadius: AC_RADIUS.lg, overflow: 'hidden' }}>
          {filtered.map((ex, i, a) => {
            const isPicked = picked.includes(ex.id);
            return (
              <button key={ex.id} onClick={() => togglePick(ex.id)} style={{
                all: 'unset', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12,
                width: '100%', boxSizing: 'border-box',
                padding: '10px 14px',
                background: isPicked ? `${accent}10` : 'transparent',
                borderBottom: i < a.length-1 ? `0.5px solid ${theme.border}` : 'none',
                transition: 'background .12s',
              }}>
                <ExerciseThumb name={ex.name} theme={theme} size={40}/>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 540, color: theme.text, letterSpacing: -0.2 }}>
                    {ex.name} <span style={{ color: theme.textSec, fontWeight: 400 }}>({ex.equip})</span>
                  </div>
                  <div style={{ fontSize: 11, color: theme.textSec, marginTop: 2 }}>{ex.muscle}</div>
                </div>
                <div style={{
                  width: 26, height: 26, borderRadius: 13,
                  background: isPicked ? accent : 'transparent',
                  border: `1px solid ${isPicked ? accent : theme.borderStrong}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0, transition: 'all .12s',
                }}>
                  {isPicked
                    ? <svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="#1a0f0a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 7.5l3 3 7-7"/></svg>
                    : <svg width="11" height="11" viewBox="0 0 12 12" stroke={theme.textTer} strokeWidth="1.6" strokeLinecap="round"><path d="M6 2v8M2 6h8"/></svg>
                  }
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function FilterChip({ theme, accent, label, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      all: 'unset', cursor: 'pointer', flex: 1, textAlign: 'center',
      padding: '8px 14px', borderRadius: 999,
      background: active ? `${accent}14` : theme.surface1,
      border: `0.5px solid ${active ? `${accent}55` : theme.border}`,
      fontSize: 13, color: active ? accent : theme.text, fontWeight: 540, letterSpacing: -0.1,
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
    }}>
      {label}
      <svg width="9" height="9" viewBox="0 0 10 10" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinecap="round"><path d="M2 4l3 3 3-3"/></svg>
    </button>
  );
}

// ════════════════════════════════════════════════════════════════════
// 4. ACTIVE WORKOUT — live "Log workout" with timer
// ════════════════════════════════════════════════════════════════════
function ScreenActiveWorkout({ theme, accent, exercises = [], onCancel, onFinish, onAddExercise }) {
  const [secs, setSecs] = React.useState(1);
  React.useEffect(() => {
    const t = setInterval(() => setSecs(s => s + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const empty = exercises.length === 0;
  const fmtTime = (s) => {
    if (s < 60) return `${s}s`;
    const m = Math.floor(s / 60), r = s % 60;
    return `${m}:${String(r).padStart(2, '0')}`;
  };

  return (
    <div style={{ background: theme.bg, minHeight: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ height: 54 }}/>

      {/* Top bar */}
      <div style={{
        padding: '8px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <button onClick={onCancel} style={{
          all: 'unset', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
          padding: '8px 8px', fontSize: 14, color: theme.text, fontWeight: 540,
        }}>
          <svg width="10" height="10" viewBox="0 0 10 10" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinecap="round"><path d="M2 4l3 3 3-3"/></svg>
          Log workout
        </button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <button style={{
            all: 'unset', cursor: 'pointer', width: 36, height: 36, borderRadius: 18,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: theme.surface1, border: `0.5px solid ${theme.border}`,
          }}>
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke={theme.text} strokeWidth="1.6" strokeLinecap="round"><circle cx="8" cy="9" r="5.5"/><path d="M8 6.5V9l1.5 1M5 2l-2 2M11 2l2 2"/></svg>
          </button>
          <button onClick={onFinish} style={{
            all: 'unset', cursor: 'pointer', padding: '8px 16px', borderRadius: 999,
            fontSize: 13, fontWeight: 600, color: '#1a0f0a',
            background: accent, letterSpacing: -0.1,
          }}>Finish</button>
        </div>
      </div>

      {/* Live stats */}
      <div style={{
        margin: '6px 16px 0',
        padding: '14px 16px', borderRadius: AC_RADIUS.lg,
        background: theme.surface1, border: `0.5px solid ${theme.border}`,
        display: 'grid', gridTemplateColumns: 'repeat(3, 1fr) auto', gap: 14, alignItems: 'center',
      }}>
        <Stat theme={theme} accent={accent} label="Duration" value={fmtTime(secs)} live/>
        <Stat theme={theme} label="Volume" value={empty ? '0' : '1.4k'} unit="kg"/>
        <Stat theme={theme} label="Sets" value={empty ? '0' : '12'}/>
        <BodyDiagram theme={theme} accent={accent}/>
      </div>

      {/* Body */}
      {empty ? (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '20px 28px' }}>
          <div style={{ marginBottom: 14, opacity: 0.5 }}>
            <DumbbellIcon color={theme.textTer} size={44}/>
          </div>
          <div style={{ fontSize: 22, fontWeight: 620, color: theme.text, letterSpacing: -0.4 }}>Get started</div>
          <div style={{ fontSize: 14, color: theme.textSec, marginTop: 6, textAlign: 'center' }}>
            Add an exercise to start your workout
          </div>
          <div style={{ width: '100%', maxWidth: 320, marginTop: 22 }}>
            <PrimaryButton accent={accent} theme={theme} fullWidth onClick={onAddExercise}
              icon={<svg width="14" height="14" viewBox="0 0 14 14" stroke="#1a0f0a" strokeWidth="2" strokeLinecap="round" fill="none"><path d="M7 2v10M2 7h10"/></svg>}
            >Add exercise</PrimaryButton>
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 12, width: '100%', maxWidth: 320 }}>
            <SecondaryButton theme={theme}>Settings</SecondaryButton>
            <button style={{
              all: 'unset', cursor: 'pointer', flex: 1, textAlign: 'center',
              padding: '12px 14px', borderRadius: AC_RADIUS.md,
              background: `${theme.bad}14`, border: `0.5px solid ${theme.bad}40`,
              color: theme.bad, fontSize: 14, fontWeight: 540,
            }}>Discard workout</button>
          </div>
        </div>
      ) : (
        <div style={{ flex: 1, padding: '16px 20px 30px' }}>
          {/* When populated: list of live exercises with set check-offs */}
          <div style={{ fontSize: 11, color: theme.textTer, letterSpacing: 1.4, textTransform: 'uppercase', fontWeight: 600, marginBottom: 10 }}>In progress</div>
        </div>
      )}
    </div>
  );
}

function Stat({ theme, accent, label, value, unit, live }) {
  return (
    <div>
      <div style={{ fontSize: 10, color: theme.textTer, letterSpacing: 1.2, textTransform: 'uppercase', fontWeight: 600, marginBottom: 4 }}>{label}</div>
      <div style={{
        fontFamily: 'var(--ac-mono)', fontSize: 18, fontWeight: 540,
        color: live ? accent : theme.text,
        fontVariantNumeric: 'tabular-nums', letterSpacing: -0.4,
      }}>
        {value}{unit && <span style={{ fontSize: 11, color: theme.textSec, marginLeft: 2 }}>{unit}</span>}
      </div>
    </div>
  );
}

function SecondaryButton({ theme, children }) {
  return (
    <button style={{
      all: 'unset', cursor: 'pointer', flex: 1, textAlign: 'center',
      padding: '12px 14px', borderRadius: AC_RADIUS.md,
      background: theme.surface1, border: `0.5px solid ${theme.border}`,
      color: theme.text, fontSize: 14, fontWeight: 540,
    }}>{children}</button>
  );
}

// ════════════════════════════════════════════════════════════════════
// SHARED ICONS / PLACEHOLDERS
// ════════════════════════════════════════════════════════════════════
function DumbbellIcon({ color, size = 28 }) {
  return (
    <svg width={size} height={size * 0.6} viewBox="0 0 50 30" fill="none" stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="9"  width="6" height="12" rx="1.5"/>
      <rect x="42" y="9" width="6" height="12" rx="1.5"/>
      <rect x="8" y="12" width="3" height="6"/>
      <rect x="39" y="12" width="3" height="6"/>
      <rect x="11" y="13.5" width="28" height="3" rx="1"/>
    </svg>
  );
}

function ExerciseThumb({ name, theme, size = 40 }) {
  // Initials in a soft tile — placeholder over a bad anatomy attempt.
  const initials = name.split(/\s|-/).filter(Boolean).slice(0,2).map(w => w[0]).join('').toUpperCase();
  return (
    <div style={{
      width: size, height: size, borderRadius: 9, flexShrink: 0,
      background: theme.surface2, border: `0.5px solid ${theme.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'var(--ac-mono)', fontSize: size * 0.32, color: theme.textSec, fontWeight: 540, letterSpacing: 0.2,
    }}>{initials}</div>
  );
}

function BodyDiagram({ theme, accent }) {
  // Tiny silhouette — just a visual cue, no real anatomy
  return (
    <svg width="32" height="44" viewBox="0 0 32 44" fill="none" stroke={theme.textTer} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="16" cy="6" r="3.2"/>
      <path d="M10 11 L8 22 L8 28 M22 11 L24 22 L24 28 M16 10 L16 24 M12 24 L11 38 L11 42 M20 24 L21 38 L21 42"/>
      <path d="M8 14 L4 22 M24 14 L28 22"/>
    </svg>
  );
}

Object.assign(window, {
  ScreenWorkoutHub, ScreenCreateRoutine, ScreenExercisePicker, ScreenActiveWorkout,
  AC_EXERCISE_LIBRARY, AC_SAVED_ROUTINES,
});
